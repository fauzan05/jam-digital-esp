const debounce = (callback, wait) => {
  let timeoutId = null;
  return (...args) => {
    window.clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => {
      callback.apply(null, args);
    }, wait);
  };
}
debounce(() => console.log())
const fetch_headerPost = {
  "Content-Type" : "application/x-www-form-urlencoded;charset=UTF-8"
};

const vm = new Vue ({
  el: "#app",
  data: () => ({
    serverApi: "http://192.168.4.1/api",
    openJadwal: false,
    jadwalSholat: {
      imsak: "--:--",
      subuh: "--:--",
      dzuhur: "--:--",
      ashar: "--:--",
      maghrib: "--:--",
      isya: "--:--",
    },
    waktuSekarang: {
      tanggal: "01",
      bulan: "Bulan",
      tahun: "Tahun",
      jam: "--",
      menit: "--",
    },
    rainbowMode: false,
    kecerahan: 0,
    kecerahanEditText: false,
    warnaSolid: 0,
    listWarnaSolid: [
      { value: 0, text: "Merah"},
      { value: 1, text: "Kuning"},
      { value: 2, text: "Hijau"},
      { value: 3, text: "Biru tua"},
      { value: 4, text: "Pink"},
      { value: 5, text: "Oranye"},
      { value: 6, text: "Biru muda"},
      { value: 7, text: "Putih"},
    ],
    alarmOn: false,
    alarmJam: "",
    rtcTanggal: "",
    rtcJam: "",
  }),
  computed: {
    modeWarna() {
      return (this.rainbowMode) ? "Rainbow" : "Solid"
    },
    styleOpenJadwal() {
      let maxHeight = 0;
      if (this.openJadwal) {
        const el = this.$refs.panelJadwal;
        maxHeight = el.scrollHeight + "px";
      }
      return {
        maxHeight
      };
    },
  },
  watch: {
    kecerahan(val) {
      this.kecerahan =  (Number(val) > 255) ? 255 : Number(val);

      this.simpanLED();
    },
    rainbowMode() {
      this.simpanLED();
    },
    warnaSolid() {
      this.simpanLED();
    }
  },
  methods: {
    async getJadwal() {
      try {
        const response = await fetch(`${this.serverApi}/jadwal`);
        const json = await response.json();
        const namaJadwal = ["imsak", "subuh", "dzuhur", "ashar", "maghrib", "isya"];

        for (let i=0; i<6; i++) {
          const jadwal_jam = String(json[namaJadwal[i] + "_jam"]).padStart(2,0);
          const jadwal_menit = String(json[namaJadwal[i] + "_menit"]).padStart(2,0);
          this.jadwalSholat[namaJadwal[i]] = `${jadwal_jam}:${jadwal_menit}`;
        }
      } catch (e) {
        console.error(e);
      }
    },
    async getWaktu() {
      try {
        const response = await fetch(`${this.serverApi}/waktu`);
        const json = await response.json();

        const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
        this.waktuSekarang.tanggal = String(json.tanggal).padStart(2,0);
        this.waktuSekarang.bulan = bulan[json.bulan-1];
        this.waktuSekarang.tahun = json.tahun;
        this.waktuSekarang.jam = String(json.jam).padStart(2,0);
        this.waktuSekarang.menit = String(json.menit).padStart(2,0);
      } catch (e) {
        console.error(e);
      }
    },
    async getSetting() {
      try {
        const response = await fetch(`${this.serverApi}/settings`);
        const json = await response.json();

        const jsonLed = json.led;
        const jsonAlarm = json.alarm;

        this.rainbowMode = jsonLed.rainbowMode;
        this.kecerahan = jsonLed.kecerahan;
        this.warnaSolid = jsonLed.warnaSolid;

        this.alarmOn = jsonAlarm.toggle;
        this.alarmJam = `${String(jsonAlarm.jam).padStart(2,0)}:${String(jsonAlarm.menit).padStart(2,0)}`
      } catch (e) {
        console.error(e);
      }
    },
    async simpanLED() {
      try {
        const send = await fetch(`${this.serverApi}/settings/led`, {
          method: "POST",
          headers: fetch_headerPost,
          body: new URLSearchParams({
            rainbowMode: this.rainbowMode,
            kecerahan: this.kecerahan,
            warnaSolid: this.warnaSolid,
          }),
        });
      } catch (e) {
        console.error(e);
        swal.fire({
          icon: "error",
          title: "Simpan LED",
          text: e,
          timerProgressBar: true,
          timer: 1500
        })
      }
    },
    async simpanAlarm() {
      try {
        const send = await fetch(`${this.serverApi}/settings/alarm`, {
          method: "POST",
          headers: fetch_headerPost,
          body: new URLSearchParams({
            toggle: this.alarmOn,
            jam: Number(this.alarmJam.substring(0,2)),
            menit: Number(this.alarmJam.substring(3,5))
          }),
        });

        if (send.ok) {
          swal.fire({
            icon: "success",
            title: "Simpan Alarm Berhasil",
            timerProgressBar: true,
            timer: 1500
          })
        } else {
          swal.fire({
            icon: "error",
            title: "Simpan Alarm",
            text: `Error code: ${send.status}`,
            confirmButtonText: "CLOSE"
          })
        }
      } catch (e) {
        console.error(e);
        swal.fire({
          icon: "error",
          title: "Simpan Alarm",
          text: e,
          timerProgressBar: true,
          timer: 1500
        })
      }
    },
    async simpanRTC() {
      try {
        if (this.rtcTanggal == "" && this.rtcJam == "") return

        const date = new Date(this.rtcTanggal);
        const data = {
          tanggal: date.getDate() || "",
          bulan: date.getMonth()+1 || "",
          tahun: date.getFullYear() || "",
          jam: this.rtcJam.substring(0,2),
          menit: this.rtcJam.substring(3,5),
        }

        const send = await fetch(`${this.serverApi}/settings/rtc`, {
          method: "POST",
          headers: fetch_headerPost,
          body: new URLSearchParams(data),
        });

        if (send.ok) {
          swal.fire({
            icon: "success",
            title: "Simpan Waktu RTC Berhasil",
            timerProgressBar: true,
            timer: 1500
          })
        } else {
          swal.fire({
            icon: "error",
            title: "Simpan Waktu RTC",
            text: `Error code: ${send.status}`,
            confirmButtonText: "CLOSE"
          })
        }
      } catch (e) {
        console.error(e);
        swal.fire({
          icon: "error",
          title: "Simpan RTC",
          text: e,
          timerProgressBar: true,
          timer: 1500
        })
      }
    },
    async matikanAlarm() {
      try {
        const response = await fetch(`${this.serverApi}/matikan_alarm`);
        if (response) {
          swal.fire({
            icon: "success",
            title: "Mematikan Alarm",
            timerProgressBar: true,
            timer: 1500
          })
        }
      } catch (e) {
        console.error(e);
        swal.fire({
          icon: "error",
          title: "Mematikan Alarm Gagal",
          text: e,
          timerProgressBar: true,
          timer: 1500
        })
      }
    },
  },
  mounted() {
    this.getJadwal();
    this.getSetting();
    this.getWaktu();

    this.intervalGetWaktu = setInterval(this.getWaktu, 3000);
  },
});
